package com.example.myapplication.ui.screens.opportunities
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.navigation.NavController
@Composable
fun ApplicationsScreen(navController: NavController) { Text("Postulaciones (Pendiente)") }