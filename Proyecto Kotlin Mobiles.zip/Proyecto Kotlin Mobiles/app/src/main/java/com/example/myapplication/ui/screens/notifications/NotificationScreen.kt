package com.example.myapplication.ui.screens.notifications
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.navigation.NavController
@Composable
fun NotificationsScreen(navController: NavController) { Text("Notificaciones (Pendiente)") }