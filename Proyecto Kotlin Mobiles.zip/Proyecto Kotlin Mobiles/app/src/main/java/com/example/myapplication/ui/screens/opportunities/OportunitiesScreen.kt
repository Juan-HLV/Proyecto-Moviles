package com.example.myapplication.ui.screens.opportunities
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.navigation.NavController
@Composable
fun OpportunitiesScreen(navController: NavController) { Text("Oportunidades (Pendiente)") }