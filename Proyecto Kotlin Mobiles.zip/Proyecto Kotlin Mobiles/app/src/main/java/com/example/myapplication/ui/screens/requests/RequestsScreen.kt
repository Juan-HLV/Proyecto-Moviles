package com.example.myapplication.ui.screens.requests

package com.example.myapplication.ui.screens.requests
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.navigation.NavController
@Composable
fun RequestsScreen(navController: NavController) { Text("Solicitudes (Pendiente)") }