package com.example.myapplication.ui.screens.reports
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.navigation.NavController
@Composable
fun ReportsScreen(navController: NavController) { Text("Reportes (Pendiente)") }