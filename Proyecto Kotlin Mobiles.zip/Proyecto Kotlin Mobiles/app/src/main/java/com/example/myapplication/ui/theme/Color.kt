package com.example.myapplication.ui.theme

import androidx.compose.ui.graphics.Color // <--- ESTO SOLUCIONA TU ERROR ROJO

val PrimaryBlue = Color(0xFF13a4ec)
val PrimaryDarkBlue = Color(0xFF005A9C)
val BackgroundLight = Color(0xFFF6F7F8)
val BackgroundDark = Color(0xFF101C22)
val White = Color.White
val Black = Color.Black