package com.example.myapplication.ui.navigation

object NavRoutes {
    const val Landing = "landing"
    const val Login = "login"
    const val Register = "register"
    const val Dashboard = "dashboard"
    const val UserProfile = "userProfile"
    const val Requests = "requests"
    const val Opportunities = "opportunities"
    const val Applications = "applications"
    const val Notifications = "notifications"
    const val Reports = "reports"
}