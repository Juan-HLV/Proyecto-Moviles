

package com.example.myapplication.ui.screens.profile
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.navigation.NavController

private val compose: Any

@Composable
fun UserProfileScreen(navController: NavController) { Text("Perfil (Pendiente)") }