package com.example.myapplication.ui.screens.dashboard

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.myapplication.ui.navigation.NavRoutes

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(navController: NavController) {
    Scaffold(topBar = { TopAppBar(title = { Text("Dashboard") }, actions = { IconButton(onClick = { navController.navigate(NavRoutes.Landing) }) { Icon(Icons.Outlined.Logout, null) } }) }) { padding ->
        Column(Modifier.padding(padding).padding(16.dp)) {
            Text("Accesos", fontWeight = FontWeight.Bold)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                IconButton(onClick = { navController.navigate(NavRoutes.UserProfile) }) { Icon(Icons.Outlined.Person, null) }
                IconButton(onClick = { navController.navigate(NavRoutes.Requests) }) { Icon(Icons.Outlined.Group, null) }
                IconButton(onClick = { navController.navigate(NavRoutes.Opportunities) }) { Icon(Icons.Outlined.Work, null) }
            }
            Spacer(Modifier.height(24.dp))
            Text("Estadísticas", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            val stats = listOf("Usuarios" to "1.2k", "Talentos" to "850", "Empresas" to "350", "Activos" to "200")
            LazyVerticalGrid(columns = GridCells.Fixed(2), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(stats) { (k, v) ->
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                        Column(Modifier.padding(16.dp)) { Text(k); Text(v, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.headlineMedium) }
                    }
                }
            }
        }
    }
}