package com.example.myapplication.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.example.myapplication.ui.screens.landing.LandingScreen
import com.example.myapplication.ui.screens.auth.LoginScreen
import com.example.myapplication.ui.screens.auth.RegisterScreen
import com.example.myapplication.ui.screens.dashboard.DashboardScreen
import com.example.myapplication.ui.screens.profile.UserProfileScreen
import com.example.myapplication.ui.screens.requests.RequestsScreen
import com.example.myapplication.ui.screens.opportunities.OpportunitiesScreen
import com.example.myapplication.ui.screens.opportunities.ApplicationsScreen
import com.example.myapplication.ui.screens.notifications.NotificationsScreen
import com.example.myapplication.ui.screens.reports.ReportsScreen

@Composable
fun AppNavHost(navController: NavHostController) {
    NavHost(navController = navController, startDestination = NavRoutes.Landing) {
        composable(NavRoutes.Landing) {
            LandingScreen(
                onLoginClick = { navController.navigate(NavRoutes.Login) },
                onRegisterClick = { navController.navigate(NavRoutes.Register) }
            )
        }
        composable(NavRoutes.Login) {
            LoginScreen(
                onLoginSuccess = { navController.navigate(NavRoutes.Dashboard) },
                onRegisterClick = { navController.navigate(NavRoutes.Register) }
            )
        }
        // Placeholder simple para Register por brevedad
        composable(NavRoutes.Register) {
            androidx.compose.material3.Text("Registro (Pendiente)") // O usa RegisterScreen si la creaste completa
        }
        composable(NavRoutes.Dashboard) { DashboardScreen(navController) }
        composable(NavRoutes.UserProfile) { UserProfileScreen(navController) }
        composable(NavRoutes.Requests) { RequestsScreen(navController) }
        composable(NavRoutes.Opportunities) { OpportunitiesScreen(navController) }
        composable(NavRoutes.Applications) { ApplicationsScreen(navController) }
        composable(NavRoutes.Notifications) { NotificationsScreen(navController) }
        composable(NavRoutes.Reports) { ReportsScreen(navController) }
    }
}